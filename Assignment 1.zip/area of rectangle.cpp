#include<iostream>
using namespace std;

int main()
{
	int l, b ,a;
	cout<<"Enter the length of the rectangle:";
	cin>>l;
	cout<<"Enter the breadth of the rectangle:";
	cin>>b;
	a=l*b;
	cout<<"Area of the rectangle is:";
	cout<<a;
	
	return 0;
}
