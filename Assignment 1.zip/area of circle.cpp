#include<iostream>
using namespace std;

int main()
{
	int r;
	float area;
	r=30;
	area=2*3.14*r;
	cout<<"area of the given circle is:";
	cout<<area;
	
	return 0;
}
