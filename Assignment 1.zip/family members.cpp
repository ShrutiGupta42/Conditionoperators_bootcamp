#include<iostream>
using namespace std;

int main()
{
	cout<<"Grandather's name: Shankarlal Gupta \n";
	
	cout<<"Father's name:Rajesh Gupta \n";
	
	cout<<"Mother's name:Meena Gupta \n";
	
	cout<<"Brother's name:Vansh Gupta \n";
	
	
	return 0;
}

