#include<iostream>
using namespace std;

int main()
{
	int c , f;
	cout<<"enter the temperature in celsius";
	cin>>c;
	f= (c*9/5)+32;
	cout<<"the temperature in farhenite is:";
	cout<<f;
	
	return 0;
}
